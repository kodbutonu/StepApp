import 'package:adim/screens/homepage.dart';
import 'package:adim/screens/register.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';

import 'introduction/onboardingscreen.dart';

main() async {

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Adım adım',
      theme: ThemeData(
        fontFamily: 'Georgia',
        textTheme: TextTheme(
            headline4: TextStyle(
                fontSize: 32.0, fontFamily: 'Hind', color: Color(0xFF00FF0A) ,
            fontWeight: FontWeight.bold),
            headline2: TextStyle(
                fontSize: 16.0, fontFamily: 'Hind', color: Color(0xE0171616)),
            headline3: TextStyle(
                fontSize: 14.0, fontFamily: 'Hind', color: Colors.black12),
            headline1: TextStyle(
                fontSize: 36.0,
                fontWeight: FontWeight.bold,
                color: Colors.white,
                fontFamily: 'Hind'),
            headline6: TextStyle(
                fontSize: 36.0, color: Colors.white, fontFamily: 'Hind'),
            bodyText2: TextStyle(
                fontSize: 14.0, fontFamily: 'Hind', color: Colors.white70),
            bodyText1: TextStyle(
                fontSize: 14.0, fontFamily: 'Hind', color: Colors.white)),
        appBarTheme:
            AppBarTheme(backgroundColor: Color.fromARGB(255, 33, 33, 33)),
        scaffoldBackgroundColor: Color.fromARGB(255, 255, 255, 255),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            primary: Colors.orange,
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              foregroundColor: Colors.black,
              disabledBackgroundColor: Colors.red,

            shadowColor: Colors.green,

              side: BorderSide(color: Colors.grey),

          ),

        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            primary: Colors.purple,
            backgroundColor: Colors.green,
          ),
        ),
      ),
      home: (RegisterScreen()),
    );
  }
}
