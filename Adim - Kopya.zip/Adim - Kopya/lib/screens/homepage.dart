import 'package:adim/screens/history.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../app/home/widgets/login.dart';
import '../app/home/widgets/loginİmage.dart';

class sign_Page extends StatefulWidget {
  const sign_Page({Key? key}) : super(key: key);

  @override
  State<sign_Page> createState() => _sign_PageState();
}

class _sign_PageState extends State<sign_Page> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.only(top: 50),
            child: Stack(
              children: [
                LogImage(),
                SizedBox(height: Get.height/3),
                Container(
                  margin: EdgeInsets.only(top: Get.height/2.5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Login(),
                      SizedBox(height: Get.height * 0.05),

                      ],
                  ),
                )

              ],
            ),
          ),
        ));
  }
}
