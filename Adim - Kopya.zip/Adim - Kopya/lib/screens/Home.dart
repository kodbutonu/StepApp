import 'package:adim/screens/graph_View.dart';
import 'package:adim/screens/history.dart';
import 'package:animated_bottom_navigation_bar/animated_bottom_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class Home extends StatefulWidget {
   Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
int current_Tab=0;

Widget _currentScreen=GraphScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:_currentScreen,
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.task_outlined),
        onPressed: null,
        backgroundColor: Color(0xFF181818),

      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

      bottomNavigationBar: AnimatedBottomNavigationBar(
gapLocation: GapLocation.center,
        height: Get.height/12,
        activeColor: Colors.white,
        inactiveColor: Colors.greenAccent,
        backgroundColor:  Color(0xFF181818),
        icons: [
          Icons.home_sharp,
          Icons.auto_graph_sharp,

        ],
        iconSize: 24,
        activeIndex: current_Tab,

        onTap: (int) {
          setState(() { current_Tab=int;
          _currentScreen=(int==0)?GraphScreen():History(); });

        },
      ),
    );
  }
}
