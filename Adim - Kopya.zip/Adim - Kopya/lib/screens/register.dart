import 'package:adim/screens/homepage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:indexed/indexed.dart';

import '../app/services/auth/auth.dart';
import '../models/background.dart';

class RegisterScreen extends StatefulWidget {
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final TextEditingController _usernamecontrol = TextEditingController();

  final TextEditingController _emailcontrol = TextEditingController();

  final TextEditingController _passwordcontrol = TextEditingController();

  final TextEditingController _passwordconfirmcontrol = TextEditingController();

  AuthServices _authServices = AuthServices();

  final _formKey = GlobalKey<FormState>();

  String? email;

  @override
  Widget build(BuildContext context) {


    return Scaffold(
      body: Form(
        key: _formKey,
        child: Stack(
          children: [
            Background(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Container(
                    alignment: Alignment.center,
                    child:
                    Image.asset('assets/image/cats.gif',height: Get.height/4,),
                  ),
                  Container(
                    alignment: Alignment.centerLeft,
                    padding: EdgeInsets.symmetric(horizontal: 40),
                    child: Text(
                      "REGISTER",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF2661FA),
                          fontSize: 36),
                      textAlign: TextAlign.left,
                    ),
                  ),
                  SizedBox(height: Get.height * 0.03),
                  Container(
                    alignment: Alignment.center,
                    margin: EdgeInsets.symmetric(horizontal: 40),
                    child: TextFormField(
                      controller: _usernamecontrol,
                      decoration: InputDecoration(labelText: "Name"),
                    ),
                  ),
                  SizedBox(height: Get.height * 0.03),
                  Container(
                    alignment: Alignment.center,
                    margin: EdgeInsets.symmetric(horizontal: 40),
                    child: TextFormField(
                      controller: _emailcontrol,
                      decoration: InputDecoration(labelText: "E-mail"),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Lütfen Mail Giriniz';
                        } else if (!value.contains("@")) {
                          return "Girilen Değer Mail Formatında olmalıdır";
                        } else {
                          email=value;
                        }
                        return null;
                      },
                    ),
                  ),
                  SizedBox(height: Get.height * 0.03),
                  Container(
                    alignment: Alignment.center,
                    margin: EdgeInsets.symmetric(horizontal: 40),
                    child: TextFormField(
                      controller: _passwordcontrol,
                      decoration: InputDecoration(labelText: "Password"),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Lütfen Şifre Giriniz';
                        } else if (value.trim().length < 6) {
                          return "Şifre 6 Karakterden Az Olamaz";
                        }
                        return null;
                      },
                    ),
                  ),
                  SizedBox(height: Get.height * 0.03),
                  Container(
                    alignment: Alignment.center,
                    margin: EdgeInsets.symmetric(horizontal: 40),
                    child: TextFormField(
                      controller: _passwordconfirmcontrol,
                      decoration: InputDecoration(labelText: "Confirm Password"),
                      obscureText: true,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Lütfen Şifre Giriniz';
                        } else if (_passwordcontrol.text !=
                            _passwordconfirmcontrol.text) {
                          return 'Şifreler Uyuşmuyor';
                        }
                        return null;
                      },
                    ),
                  ),
                  SizedBox(height: Get.height * 0.05),
                  Container(
                    alignment: Alignment.centerRight,
                    margin: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
                    child: ElevatedButton(
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          _authServices
                              .createPerson(_usernamecontrol.text,
                              _emailcontrol.text, _passwordcontrol.text)
                              .then((value) {
                            return null;
                          }).catchError((dynamic error) {
                            if (error.code.contains('email-already-in-use')) {
                              Get.snackbar("HATA!", "Mail Adresi Kullanılıyor");
                            }
                            print(error.code);
                          });
                        }
                      },
                      child: Container(
                        alignment: Alignment.center,
                        height: 50.0,
                        width: Get.width * 0.5,
                        decoration: new BoxDecoration(
                            borderRadius: BorderRadius.circular(80.0),
                            gradient: new LinearGradient(colors: [
                              Color.fromARGB(255, 255, 136, 34),
                              Color.fromARGB(255, 255, 177, 41)
                            ])),
                        padding: const EdgeInsets.all(0),
                        child: Text(
                          "SIGN UP",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    alignment: Alignment.centerRight,
                    margin: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
                    child: GestureDetector(
                      onTap: () => {
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context) => sign_Page()))
                      },
                      child: Text(
                        "Already Have an Account? Sign in",
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF2661FA)),
                      ),
                    ),
                  )
                ],),
            ),
          ],
        ),
        )
    );
  }
}
