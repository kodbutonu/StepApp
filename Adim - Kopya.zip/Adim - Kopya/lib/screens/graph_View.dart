import 'package:flutter/material.dart';

import '../models/report.dart';

class GraphScreen extends StatefulWidget {
  const GraphScreen({Key? key}) : super(key: key);

  @override
  State<GraphScreen> createState() => _GraphScreenState();
}

class _GraphScreenState extends State<GraphScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0x38000000),
        appBar: AppBar(
          centerTitle: true,
          title: Text('Walk',style: Theme.of(context).textTheme.headline6),
        ),
        body: Graphic());
  }
}
