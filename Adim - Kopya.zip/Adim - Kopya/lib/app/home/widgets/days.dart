import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:flutter/material.dart';

import 'DaysContainer.dart';

class Days extends StatefulWidget {
  const Days({Key? key}) : super(key: key);

  @override
  State<Days> createState() => _DaysState();
}

class _DaysState extends State<Days> {
  bool isOkay = false;
  int aimStep = 10000;
  int doneStep = 10000;
  void checkDailyStep(){
    if(aimStep <= doneStep){
      setState(() {
        isOkay = true;
      });
    }else {
      return;
    }
  }
  @override
  void initState() {

    // TODO: implement initState
    super.initState();
    checkDailyStep();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
       margin: EdgeInsets.only(top:Get.height/1.8,left: Get.width/20,right:Get.width/20,),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(50),
            color: Color(
                0xC5252525) //set border radius to 50% of square height and width
            ),
        width: Get.width,
        child: Container(
          margin: EdgeInsets.all(20),
          child: SizedBox(
            width: Get.width,
            child: Row(

              children: [
                DayContainer(isOkay: isOkay,daysName: "Mon",),
                DayContainer(daysName: "Tue"),
                DayContainer(daysName: "Wed"),
                DayContainer(daysName: "Thu"),
                DayContainer(daysName: "Fri"),
                DayContainer(daysName: "Sat"),
                DayContainer(daysName: "Sun"),
              ],
            ),
          ),
        ));

  }
}

