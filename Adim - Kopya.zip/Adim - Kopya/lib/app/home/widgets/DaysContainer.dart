
import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';


class DayContainer extends StatelessWidget {
  bool isOkay;
  int flexNum;
  final String daysName;
  DayContainer({

    Key? key,this.flexNum = 1, this.isOkay = false,required this.daysName
  }) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Flexible(
      flex: flexNum,
      fit: FlexFit.tight,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CircularPercentIndicator(
            radius: 15,
            lineWidth: 2.0,
            percent: 0.7,
            center:isOkay?Icon(Icons.done,color: Colors.white,):Icon(Icons.close,color: Colors.white,),
            progressColor: isOkay?Colors.green:Colors.red,
          ),
          SizedBox(height: 10,),
          Text(
            daysName,
            style: Theme.of(context).textTheme.bodyText2,
          ),
        ],
      ),
    );
  }
}
