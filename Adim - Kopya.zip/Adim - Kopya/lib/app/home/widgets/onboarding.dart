import 'package:flutter/material.dart';

Widget buildPage({
  required Color color,
  required String urlImage,
  required String title,
  required String subtitle,
}) => Container(
  color: color,
  child: Column(
    mainAxisAlignment: MainAxisAlignment.start,
    children: [
      Image.asset(urlImage,fit: BoxFit.cover,width: double.infinity,),
      //const SizedBox(height: 10,),
      Text(
        title,
        style: TextStyle(color: Colors.teal.shade700,fontSize: 32,fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 24,),
      Container(
        padding: EdgeInsets.symmetric(horizontal: 5),
        child: Text(
          subtitle,
          style: TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.normal),
          textAlign: TextAlign.center,
        ),
      )
    ],
  ),
);

