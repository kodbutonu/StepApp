import 'package:flutter/material.dart';

class BarChartWidget extends StatefulWidget {

  const BarChartWidget({Key? key}) : super(key: key);

  @override
  State<BarChartWidget> createState() => _BarChartWidgetState();
}

class _BarChartWidgetState extends State<BarChartWidget> {
  final double barWidth=22;
  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
    );
  }
}
