import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class LogImage extends StatefulWidget {
  const LogImage({Key? key}) : super(key: key);

  @override
  State<LogImage> createState() => _LogImageState();
}

class _LogImageState extends State<LogImage> {
  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.only(
          top: 50,
        ),
        child: Stack(children: [
          Container(
            height: Get.height / 3,
            width: Get.width,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    colors: [Color.fromARGB(255, 1, 255, 7), Colors.white],
                    begin: Alignment.topLeft),
                borderRadius:
                    BorderRadius.only(topRight: Radius.circular(200))),
            child: Row(
              children: [
                Container(
                  margin: EdgeInsets.only(bottom: Get.height / 6),
                  alignment: Alignment.center,
                  child: Row(
                    children: [
                      Image.asset('assets/image/cat.gif'),
                      SizedBox(
                        width: 40,
                      ),
                      Image.asset(
                        'assets/image/sun.gif',
                        height: Get.height / 5,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(left: Get.width / 4),
            alignment: Alignment.center,
            decoration: BoxDecoration(
                borderRadius:
                    BorderRadius.only(topLeft: Radius.circular(1000))),
            width: Get.width,
            height: Get.height / 2,
            child: Row(
              children: [
                Image.asset(
                  'assets/image/dog.gif',
                  height: Get.height / 10,
                ),
                Image.asset(
                  'assets/image/2.gif',
                  height: Get.height / 4,
                ),
              ],
            ),
          ),
        ]));
  }
}
