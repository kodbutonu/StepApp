import 'package:drop_shadow/drop_shadow.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../../screens/Home.dart';
import '../../services/auth/auth.dart';
class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final TextEditingController _emailcontrol = TextEditingController();
  final TextEditingController _passwordcontrol = TextEditingController();

  AuthServices _authServices = AuthServices();

  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
     return Form(
       key: _formKey,
       child: Column(
         children: [
           Container(
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              "LOGIN",
              style: Theme.of(context).textTheme.headline4,
              textAlign: TextAlign.left,
            ),
    ),

    SizedBox(height: Get.height *0.009),

    Container(
    alignment: Alignment.center,
    margin: EdgeInsets.symmetric(horizontal: 40),
    child: TextField(
      controller: _emailcontrol,
    decoration: InputDecoration(labelText: "E-mail",
        fillColor: Colors.white,
        focusedBorder:OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.black),

        ),),
    ),
    ),
    SizedBox(height: Get.height * 0.03),
    Container(
    alignment: Alignment.center,
    margin: EdgeInsets.symmetric(horizontal: 40),
    child: TextField(controller:_passwordcontrol ,
    decoration: InputDecoration(labelText: "Password"),
    obscureText: true,
    ),
    ),
    Container(
    alignment: Alignment.centerRight,
    margin: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
    child: Text(
    "Forgot your password?",
    style: Theme.of(context).textTheme.headline2),
    ),
         Container(
           child: DropShadow(
             child: ElevatedButton(
               child:  Text('Submit',style:Theme.of(context).textTheme.headline2 ,),
               onPressed: () {
                 if (_formKey.currentState!.validate()) {
                   _authServices
                       .signIn(_emailcontrol.text, _passwordcontrol.text)
                       .then((value) {
                     Get.to(Home());
                   }).catchError((dynamic error){
                     if(error.code.contains('user-not-found')){
                       Get.snackbar("HATA!", "Böyle Bir Mail Adresi Yok");
                     }
                     else if(error.code.contains('wrong-password')){
                       Get.snackbar("HATA!", "Şifre Yanlış");
                     }

                     print(error.code);
                   });


                 }
               },
             ),
           ),
         )
    ]),
     );
  }
}
