import 'package:get/get.dart';

class Controller extends GetxController{
  RxInt count=1000.obs;


  int increment(int step){
    return (count=count+step) as int ;
  }
}