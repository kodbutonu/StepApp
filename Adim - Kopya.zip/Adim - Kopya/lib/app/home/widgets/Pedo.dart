
import 'package:adim/app/home/widgets/PedometerContainer.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class Picker extends StatelessWidget {
  const Picker({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.only(top: Get.height/12, left: Get.width/20, right: Get.width/20),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(50),
            color: Color(
                0xC5252525) //set border radius to 50% of square height and width
            ),
        height: 100,
        width: Get.width,

          child:PedometerContainer()


          );

  }
}
