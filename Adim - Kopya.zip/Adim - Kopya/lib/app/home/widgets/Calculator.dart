import 'dart:math';
import 'package:adim/app/home/widgets/days.dart';
import 'package:adim/models/play.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:pedometer/pedometer.dart';
import 'package:permission_handler/permission_handler.dart';

import 'package:step_progress_indicator/step_progress_indicator.dart';

import 'controller.dart';
class Calculator extends StatefulWidget {
  const Calculator({Key? key}) : super(key: key);

  @override
  State<Calculator> createState() => _CalculatorState();
}

class _CalculatorState extends State<Calculator> {
  late Stream<StepCount> _stepCountStream;
  late Stream<PedestrianStatus> _pedestrianStatusStream;
  String _status = '?', _steps = '?';

  @override
  void initState() {
    super.initState();
    initPlatformState();
  }

  void onStepCount(StepCount event) {
    print(event);
    setState(() {
      _steps = event.steps.toString();
    });
  }

  void onPedestrianStatusChanged(PedestrianStatus event) {
    print(event);
    setState(() {
      _status = event.status;
    });
  }

  void onPedestrianStatusError(error) {
    print('onPedestrianStatusError: $error');
    setState(() {
      _status = 'Pedestrian Status not available';
    });
    print(_status);
  }

  void onStepCountError(error) {
    print('onStepCountError: $error');
    setState(() {
      _steps = 'Step Count not available';
    });
  }

  void initPlatformState()  async{
    if (await Permission.activityRecognition.request().isGranted) {
      _pedestrianStatusStream = Pedometer.pedestrianStatusStream;
      _pedestrianStatusStream
          .listen(onPedestrianStatusChanged)
          .onError(onPedestrianStatusError);

      _stepCountStream = Pedometer.stepCountStream;
      _stepCountStream.listen(onStepCount).onError(onStepCountError);
      print('object');
    }else{

    }
    if (!mounted) return;
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          margin: EdgeInsets.all(20),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(50),
              color: Color(
                  0xC5252525) //set border radius to 50% of square height and width
          ),
          width: Get.width,
          child: Container(
            margin: EdgeInsets.all(20),
            width: 250,
            height: 320,
            child: Center(
              child: CircularStepProgressIndicator(
                totalSteps: 20,
                currentStep: 14,
                stepSize: 50,
                selectedColor: Colors.greenAccent,
                unselectedColor: Colors.black,
                padding: pi / 80,
                width: 300,
                height: 350,
                startingAngle: pi * 2 / 3,
                arcSize: pi * 2 / 3 * 2,

                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.all(20),
                      height: 180.0,
                      width: 350.0,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(350),
                          color: Color(
                              0xFF282828) //set border radius to 50% of square height and width
                      ),
                      child: Center(
                        child: Container(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                               Text(
                                _steps,
                                style: Theme.of(context).textTheme.headline1,
                              ),
                              Text(
                                'Steps',
                                style: Theme.of(context).textTheme.bodyText2,
                              ),

                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        Column(
          children: [
            Center(
              child: Container(
                  child:Use(),
                  margin: EdgeInsets.only(top: 250,),
                  height: 70.0,
                  width: 70.0,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(350),
                    color: Color(
                        0xFFFF6200) ,//set border radius to 50% of square height and width
                  )),

            ),

          ],
        ),
        Days(),
      ],
    );
  }
}
