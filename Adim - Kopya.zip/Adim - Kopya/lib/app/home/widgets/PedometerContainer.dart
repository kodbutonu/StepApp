import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../../models/Pedometerİmage.dart';
class PedometerContainer extends StatelessWidget {
  const PedometerContainer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: Get.width/20,right: Get.width/20),
      child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
          PedometerImage(image:'assets/image/distance.png'),
      Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Kilometer',
            style: Theme.of(context).textTheme.bodyText1,
          ),
          Text(
          'Kilometer',
          style: Theme.of(context).textTheme.bodyText2,
          ),
        ],
      ),
      PedometerImage(image:'assets/image/24-hours.png'),
      Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Saat',
            style: Theme.of(context).textTheme.bodyText1,
          ),
          Text(
          'Hours',
          style: Theme.of(context).textTheme.bodyText2,
          ),
        ],
      ),
      PedometerImage(image:'assets/image/calories.png'),
      Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Kilometer',
            style: Theme.of(context).textTheme.bodyText1,
          ),
          Text(
          'Calories',
          style: Theme.of(context).textTheme.bodyText2,
          ),
        ],
      )]),
    );
  }
}
