import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class IntroPage2 extends StatelessWidget {
  const IntroPage2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment(0.6, 0.8),
            colors: <Color>[
              Color(0xfffB4AEFF),
              Color(0xffe544E9C),
            ],
            tileMode: TileMode.mirror,
          ),
        ),
        child: Scaffold(
          backgroundColor: Colors.white,
          body: SafeArea(
            child: SingleChildScrollView(
              child: Padding(
                padding:
                const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 50,
                    ),
                    Center(
                      child: Container(
                          alignment: Alignment.center,
                          height: 250,
                          width: 300,

                          child: Center(
                            child: Container(

                                child: Lottie.network('https://assets9.lottiefiles.com/packages/lf20_b7cryg2b.json')
                            ),
                          )),
                    ),
                    const SizedBox(
                      height: 50,
                    ),
                    const Text(
                      "Sizi bu problemlerden kurtarıp, aramızda görmekten mutluluk duyarız.",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 24,color: Colors.black),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
