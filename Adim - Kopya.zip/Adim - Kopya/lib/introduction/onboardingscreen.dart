import 'package:adim/introduction/intro_1.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/get_core.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import '../models/buttondesign.dart';
import '../screens/homepage.dart';
import '../screens/register.dart';
import 'intro_2.dart';

class OnboardScreen extends StatefulWidget {
  const OnboardScreen({Key? key}) : super(key: key);

  @override
  State<OnboardScreen> createState() => _OnboardScreenState();
}

class _OnboardScreenState extends State<OnboardScreen> {
  PageController _controller = PageController();

  bool onLastPage = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          PageView(
            controller: _controller,
            onPageChanged: (index) {
              setState(() {
                onLastPage = (index == 1);
              });
            },
            children: [
              IntroPage1(),
              IntroPage2(),
            ],
          ),
          Container(
            padding: EdgeInsets.only(bottom: 20),
            alignment: Alignment(0, 0.92),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                onLastPage
                    ? Column(
                  children: [
                    ButtonDesign(
                      text: 'Hesabım Var',
                      onPressed: () {
                        Get.to(
                          const sign_Page(),
                        );
                      },
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    ButtonDesign(
                      text: 'Hesabım Yok',
                      onPressed: () {
                        Get.to(
                          RegisterScreen(),
                        );
                      },
                    ),
                  ],
                )
                    : ButtonDesign(
                  text: 'EVET',
                  onPressed: () {
                    _controller.nextPage(
                      duration: const Duration(milliseconds: 500),
                      curve: Curves.easeIn,
                    );
                  },
                ),
                const SizedBox(
                  height: 50,
                ),
                SmoothPageIndicator(
                  controller: _controller,
                  count: 2,
                  effect: const WormEffect(
                      dotColor: Color(0xfffB4AEFF), activeDotColor: Colors.black),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
