import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class IntroPage1 extends StatelessWidget {
  const IntroPage1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment(0.6, 0.8),
            colors: <Color>[
              Color(0xfffB4AEFF),
              Color(0xffe544E9C),
            ],
            tileMode: TileMode.mirror,
          ),
        ),
        child: Scaffold(
          backgroundColor: Colors.white,
          body: SafeArea(
            child: SingleChildScrollView(
              child: Padding(
                padding:
                const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 50,
                    ),
                    Center(
                      child: Container(
                          alignment: Alignment.center,
                          height: 300,
                          width: 250,

                          child: Center(
                            child: Container(


                                child: Lottie.network('https://assets1.lottiefiles.com/packages/lf20_ls1v2j0r.json')
                            ),
                          )),
                    ),
                    const SizedBox(
                      height: 70,
                    ),
                    const Text("Siz de telefon parçaları alırken güven sorunu yaşayanlardan mısınız?",textAlign: TextAlign.center,style: TextStyle(fontSize: 24,color: Colors.black),)
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
