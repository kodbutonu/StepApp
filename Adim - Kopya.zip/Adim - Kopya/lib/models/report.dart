
import 'package:adim/app/home/widgets/Calculator.dart';
import 'package:flutter/material.dart';

import '../app/home/widgets/Pedo.dart';

class Graphic extends StatefulWidget {
  const Graphic({Key? key}) : super(key: key);

  @override
  State<Graphic> createState() => _GraphicState();
}

class _GraphicState extends State<Graphic> {
  @override
  Widget build(BuildContext context) {

    return SingleChildScrollView(
      child: Container(
        color: Colors.black,
        child: Column(children: [
          Calculator(),
          Picker(),
        ],),
      )

    );
  }
}
