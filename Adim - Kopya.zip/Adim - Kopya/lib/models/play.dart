import 'package:flutter/material.dart';
import 'package:like_button/like_button.dart';
class Use extends StatelessWidget {
  const Use({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var buttonSize=50.0;
    return LikeButton(
      size: buttonSize,


      likeBuilder: (bool isLiked) {
        return Icon(
          Icons.play_arrow,
          color: isLiked ? Colors.greenAccent : Colors.white24,
          size: buttonSize,
        );
      },

    );
  }
}
