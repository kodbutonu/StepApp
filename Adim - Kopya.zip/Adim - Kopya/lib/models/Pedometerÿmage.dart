import 'package:flutter/material.dart';

class PedometerImage extends StatelessWidget {
  final double width;
  final double height;
  final String image;
  const PedometerImage(
      {Key? key, this.width = 45, this.height = 45,required this.image})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Image.asset(image,height: height,width: width,);
  }
}
