import 'package:flutter/material.dart';

class ButtonDesign extends StatefulWidget {
  Function onPressed;
  bool onFirstPressed;
  String text;
  IconData icon;

  ButtonDesign({Key? key,required this.onPressed,this.onFirstPressed = true,this.text = 'İLERİ',this.icon= Icons.arrow_forward,}) : super(key: key);

  @override
  State<ButtonDesign> createState() => _ButtonDesignState();
}

class _ButtonDesignState extends State<ButtonDesign> {




  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        widget.onPressed();
        setState(() {
          widget.onFirstPressed = false;

        });



      },
      child: Container(
        height: widget.onFirstPressed ? 45 : 42,
        width: widget.onFirstPressed ? 180 : 170,
        decoration: BoxDecoration(boxShadow: [
          BoxShadow(
              blurRadius: 12,
              offset: widget.onFirstPressed ? Offset(0.0, 8.0) : Offset(0.0, 0.0),
              color: Colors.black54),
        ], color: Colors.white, borderRadius: BorderRadius.circular(22)),
        child: Row(
          children: [
            Container(
              height: widget.onFirstPressed ? 45 : 42,
              width: widget.onFirstPressed ? 135 : 125,
              child: Center(
                  child: Text(
                    widget.text,
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight:
                        widget.onFirstPressed ? FontWeight.normal : FontWeight.bold,
                        color: Colors.black),
                    textAlign: TextAlign.center,
                  )),
              decoration: BoxDecoration(
                color: Color(0xfffB4AEFF),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(95),
                  topLeft: Radius.circular(95),
                  bottomRight: Radius.circular(200),
                ),
              ),
            ),
            Icon(
              widget.icon,
              size: widget.onFirstPressed
                  ?30:25,
              color: Colors.black,)

          ],
        ),
      ),
    );
  }
}
